<?php
$con=mysqli_connect("localhost","id19510424_root","\k<G0~@G&KqPw0eK","id19510424_blood") ;
$con=mysqli_connect("localhost","id19510424_root","\k<G0~@G&KqPw0eK","id19510424_blood") ;
?>